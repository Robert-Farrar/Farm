drop database if exists Store;
drop user if exists 'user'@'localhost';
create database Store;
use Store;

create user 'user'@'localhost' identified by 'pass';
grant all on Store.* to 'user'@'localhost';

USE Store;

CREATE TABLE Stores (
    storeID INT AUTO_INCREMENT PRIMARY KEY,
    storeLocation VARCHAR(255) NOT NULL
);
