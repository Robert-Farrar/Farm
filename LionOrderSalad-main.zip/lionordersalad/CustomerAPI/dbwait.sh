#!/bin/bash
echo "Waiting for database to start"
until nc -z -v -w30 customer-db 3306
do 
    echo "Database is unavailable"
    sleep 5
done
echo "Database is up!" 

exec "$@"