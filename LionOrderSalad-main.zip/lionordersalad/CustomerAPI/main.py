import time
from sqlalchemy.exc import OperationalError
from fastapi import FastAPI, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import Column, Integer, String, create_engine
from sqlalchemy.orm import Session, declarative_base, sessionmaker
from typing import Optional

base = declarative_base()

class Customers(base):
    __tablename__ = "Customers"
    customerID = Column(Integer, primary_key=True, index=True)
    username = Column(String, unique=True, nullable=False)
    passwrd = Column(String, nullable=False) 
    fullName = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    customerAddress = Column(String, nullable=False)
    phoneNumber = Column(String, nullable=False)

class Customer(BaseModel):
    customerID: Optional[int] = None
    username: str = Field(max_length=255)
    passwrd: str = Field(max_length=255)
    fullName: str = Field(max_length=255)
    email: str = Field(max_length=255)
    customerAddress: str = Field(max_length=255)
    phoneNumber: str = Field(max_length=255)

app = FastAPI()

@app.get("/")
def home():
    return {"message": "FastAPI is running"}


databaseURL = "mysql+pymysql://user:pass@customer-db:3306/Customer"
engine = create_engine(databaseURL)
sessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
base.metadata.create_all(bind=engine)

def getSession():
    retries = 5  
    db = None
    while retries > 0:
        try:
            db = sessionLocal()
            yield db  
            return  
        except OperationalError:
            print("Database not ready yet. Retrying in 5 seconds...")
            time.sleep(5)
            retries -= 1
        finally:
            if db is not None:
                db.close()  

@app.get("/{id}")
def getCustomersByID(id: int, db: Session = Depends(getSession)):
    customer = db.query(Customers).filter(Customers.customerID == id).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    return customer

@app.get("/username/{username}")
def getCustomerID(username: str, db: Session = Depends(getSession)):
    customer = db.query(Customers).filter(Customers.username == username).first()
    if not customer:
        raise HTTPException(status_code=404, detail="Customer not found")
    return {"customer_id": customer.customerID}

class LoginRequest(BaseModel):
    username: str
    password: str  

@app.post("/login")
def checkCredentials(login: LoginRequest, db: Session = Depends(getSession)):
    customer = db.query(Customers).filter(Customers.username == login.username).first()
    
    if not customer:
        raise HTTPException(status_code=401, detail="Invalid credentials")

    if customer.passwrd != login.password: 
        raise HTTPException(status_code=401, detail="Invalid credentials")

    return {"success": True, "user_id": customer.customerID}

@app.post("/create_customer")
def insertCustomer(customer: Customer, db: Session = Depends(getSession)):
    new_customer = Customers(
        username=customer.username,
        passwrd=customer.passwrd,  
        fullName=customer.fullName,
        email=customer.email,
        customerAddress=customer.customerAddress,
        phoneNumber=customer.phoneNumber
    )

    try:
        db.add(new_customer)
        db.commit()
        db.refresh(new_customer)  
        return {"message": "Customer created successfully", "customer_id": new_customer.customerID}
    except:
        db.rollback()
        raise HTTPException(status_code=400, detail="Username or email already exists.")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8004)