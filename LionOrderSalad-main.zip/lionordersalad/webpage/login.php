<?php
session_start();

$error_message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $api_url = "http://customer-api:8004/login"; 
    $data = json_encode([
        "username" => $_POST["username"],
        "password" => $_POST["password"]
    ]);

    $options = [
        "http" => [
            "header"  => "Content-Type: application/json",
            "method"  => "POST",
            "content" => $data
        ]
    ];

    $context = stream_context_create($options);
    $response = @file_get_contents($api_url, false, $context);

    if ($response === false) {
        $error_message = "Error: Could not connect or credientials are invalid.";
    } else {
        $result = json_decode($response, true);

        if (isset($result["success"]) && $result["success"] === true) {
            $_SESSION["user_id"] = $result["user_id"];
            $_SESSION["username"] = $_POST["username"];
            header("Location: index.php"); 
            exit();
        } else {
            $error_message = "Invalid username or password.";
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="d-flex justify-content-center align-items-center vh-100 bg-light">

    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow p-4">
                    <h2 class="text-center mb-4">Login</h2>

                    <?php if (!empty($error_message)) { ?>
                        <div class="alert alert-danger text-center"><?php echo $error_message; ?></div>
                    <?php } ?>

                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Username</label>
                            <input type="text" name="username" id="username" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Password</label>
                            <input type="password" name="password" id="password" class="form-control" required>
                        </div>
                        <button type="submit" name="verify" class="btn btn-primary w-100">Submit</button>
                    </form>

                    <div class="d-flex justify-content-center align-items-center mt-3">
                        <small class="form-text text-muted me-2">Do not have an account?</small>
                        <a class="nav-link text-primary" href="createAccount.php">Click here</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
